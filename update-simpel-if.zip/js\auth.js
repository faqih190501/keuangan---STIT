/**
 * SIMPEL-IF Role-Based Access Control (RBAC) & Navigation Manager
 * STIT Ihsanul Fikri
 * Hanya 2 peran utama: ADMIN (Pengelola/Keuangan) & MAHASISWA (Portal Mahasiswa)
 */

import { appState } from './state.js';
import { USER_ROLES } from './models.js';

export const ROLE_PERMISSIONS = {
  ADMIN: {
    allowedViews: [
      'dashboard-bendahara',
      'view-matriks-rekap',
      'view-skema-tarif',
      'view-verifikasi',
      'view-akademik',
      'view-kalender',
      'view-laporan',
      'view-audit-log',
      'view-qr-validator',
      'view-login'
    ],
    defaultView: 'dashboard-bendahara'
  },
  MAHASISWA: {
    allowedViews: [
      'view-mahasiswa',
      'view-kalender',
      'view-qr-validator',
      'view-login'
    ],
    defaultView: 'view-mahasiswa'
  }
};

// Aliases
ROLE_PERMISSIONS.BENDAHARA = ROLE_PERMISSIONS.ADMIN;
ROLE_PERMISSIONS.PIMPINAN = ROLE_PERMISSIONS.ADMIN;
ROLE_PERMISSIONS.AKADEMIK = ROLE_PERMISSIONS.ADMIN;

export class AuthManager {
  static init() {
    this.renderRoleBar();
    this.updateSidebarNav();
  }

  static renderRoleBar() {
    const isAuthed = appState.isAuthenticated();
    if (!isAuthed) {
      this.updateSidebarNav();
      return;
    }

    const state = appState.getState();
    const currentRole = state.currentRole === 'MAHASISWA' ? 'MAHASISWA' : 'ADMIN';
    const currentUser = state.currentUser || {};

    // Update topbar / sidebar current user display
    const userNameEl = document.getElementById('topbar-user-name');
    const userRoleEl = document.getElementById('topbar-user-role');
    const userAvatarEl = document.getElementById('topbar-user-avatar');
    const topbarProfNameEl = document.getElementById('btn-topbar-profile-name');

    const roleObj = USER_ROLES[currentRole] || USER_ROLES.ADMIN;
    const displayName = currentUser.name || roleObj.defaultUser;
    if (userNameEl) userNameEl.textContent = displayName;
    if (userRoleEl) userRoleEl.textContent = `${currentRole === 'ADMIN' ? (currentUser.title ? 'Bendahara' : 'Admin') : 'Mahasiswa'} ⚙️`;
    if (userAvatarEl) userAvatarEl.textContent = currentUser.avatarText || roleObj.avatarText;
    if (topbarProfNameEl) topbarProfNameEl.textContent = currentRole === 'ADMIN' ? 'Profil Admin' : 'Profil Mahasiswa';

    // Hide/show topbar register button for Mahasiswa
    const btnTopRegister = document.getElementById('btn-topbar-register');
    if (btnTopRegister) {
      btnTopRegister.style.display = currentRole === 'MAHASISWA' ? 'none' : 'inline-flex';
    }

    this.updateSidebarNav();
  }

  static updateSidebarNav() {
    const isAuthed = appState.isAuthenticated();
    const state = appState.getState();
    const isStudent = state.currentRole === 'MAHASISWA';

    const navDashboard = document.getElementById('nav-dashboard');
    const navMatriksRekap = document.getElementById('nav-matriks-rekap');
    const navSkema = document.getElementById('nav-skema');
    const navVerifikasi = document.getElementById('nav-verifikasi');
    const navKalender = document.getElementById('nav-kalender');
    const navAkademik = document.getElementById('nav-akademik');
    const navLaporan = document.getElementById('nav-laporan');
    const navAuditLog = document.getElementById('nav-audit-log');
    const navMahasiswa = document.getElementById('nav-mahasiswa');
    const navKelolaAdmin = document.getElementById('nav-kelola-admin');
    const navDaftarMahasiswa = document.getElementById('nav-daftar-mahasiswa');
    const navLogin = document.getElementById('nav-login');
    const navQr = document.getElementById('nav-qr-validator');

    if (!isAuthed) {
      [navDashboard, navMatriksRekap, navSkema, navVerifikasi, navKalender, navAkademik, navLaporan, navAuditLog, navMahasiswa, navKelolaAdmin, navDaftarMahasiswa].forEach(el => {
        if (el) el.style.display = 'none';
      });
      if (navLogin) navLogin.style.display = 'flex';
      if (navQr) navQr.style.display = 'flex';
      return;
    }

    if (navDaftarMahasiswa) navDaftarMahasiswa.style.display = isStudent ? 'none' : 'flex';
    if (navMatriksRekap) navMatriksRekap.style.display = isStudent ? 'none' : 'flex';

    if (isStudent) {
      if (navDashboard) navDashboard.style.display = 'none';
      if (navMatriksRekap) navMatriksRekap.style.display = 'none';
      if (navSkema) navSkema.style.display = 'none';
      if (navVerifikasi) navVerifikasi.style.display = 'none';
      if (navAkademik) navAkademik.style.display = 'none';
      if (navLaporan) navLaporan.style.display = 'none';
      if (navAuditLog) navAuditLog.style.display = 'none';
      if (navKelolaAdmin) navKelolaAdmin.style.display = 'none';
      if (navKalender) navKalender.style.display = 'flex';
      if (navMahasiswa) navMahasiswa.style.display = 'flex';
    } else {
      if (navDashboard) navDashboard.style.display = 'flex';
      if (navMatriksRekap) navMatriksRekap.style.display = 'flex';
      if (navSkema) navSkema.style.display = 'flex';
      if (navVerifikasi) navVerifikasi.style.display = 'flex';
      if (navAkademik) navAkademik.style.display = 'flex';
      if (navKalender) navKalender.style.display = 'flex';
      if (navLaporan) navLaporan.style.display = 'flex';
      if (navAuditLog) navAuditLog.style.display = 'flex';
      if (navKelolaAdmin) navKelolaAdmin.style.display = 'flex';
      if (navMahasiswa) navMahasiswa.style.display = 'flex';
    }
  }

  static switchRole(roleKey, customStudentNim = null) {
    if (!appState.isAuthenticated()) {
      if (window.simpelRouter) window.simpelRouter.navigateTo('view-login');
      return;
    }
    const state = appState.getState();
    // Security Guard: Mahasiswa cannot switch role to ADMIN
    if (state.currentRole === 'MAHASISWA' && roleKey === 'ADMIN') {
      window.simpelToast?.show('Akses Ditolak', 'Akun mahasiswa tidak memiliki wewenang untuk beralih ke Admin.', 'danger');
      return;
    }
    const targetRole = roleKey === 'MAHASISWA' ? 'MAHASISWA' : 'ADMIN';
    appState.setRole(targetRole, customStudentNim);
    this.renderRoleBar();

    const perms = ROLE_PERMISSIONS[targetRole] || ROLE_PERMISSIONS.ADMIN;
    const defaultView = perms.defaultView;

    // Trigger router navigation to default view for this role
    if (window.simpelRouter) {
      window.simpelRouter.navigateTo(defaultView);
    }
  }

  static logout() {
    appState.logout();
    document.body.classList.add('guest-mode');
    document.body.setAttribute('data-view', 'view-login');
    const mobileBtn = document.getElementById('mobile-menu-btn');
    if (mobileBtn) mobileBtn.style.setProperty('display', 'none', 'important');
    const sidebar = document.getElementById('sidebar');
    if (sidebar) sidebar.classList.remove('mobile-open');

    this.renderRoleBar();
    this.updateSidebarNav();
    if (window.simpelRouter) {
      window.simpelRouter.navigateTo('view-login');
      window.simpelToast.show('Logout Berhasil', 'Anda telah keluar dari sesi aktif.', 'info');
    }
  }
}
